<?php
session_start();
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Portal - Find Your Dream Job</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
        }

        .hero-section {
            height: 100vh;
            color: white;
            padding: 0;
            position: relative;
            background: url('https://images.unsplash.com/photo-1556740749-887f6717d7e4?crop=entropy&cs=tinysrgb&fit=max&ixid=MXwyMDg1MnwzNjV8c2VhY2h8Mnx8fGJ1c2luZXNzZyUyMHdoaXRlfGVufDB8fHw%3D') center/cover no-repeat;
        }

        .carousel-item {
            height: 100vh;
            background-size: cover;
            background-position: center;
            position: relative;
        }

        .carousel-item .overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.4);
        }

        .hero-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            z-index: 2;
        }

        .hero-text h1 {
            font-weight: 700;
            font-size: 4rem;
            color: #f8b400;
        }

        .hero-text p {
            font-size: 1.5rem;
            font-weight: 300;
            margin-bottom: 30px;
            color: #f8f8f8;
        }

        .login-section {
            padding: 80px 0;
            background-color: #fff;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: #f8b400;
            color: white;
            border-radius: 15px 15px 0 0;
            padding: 25px;
            text-align: center;
        }

        .card-header h4 {
            font-weight: 600;
            font-size: 1.7rem;
        }

        .btn-primary {
            background-color: #f8b400;
            border-color: #f8b400;
            font-weight: 600;
        }

        .btn-primary:hover {
            background-color: #f57c00;
            border-color: #f57c00;
        }

        .btn-outline-primary {
            border-color: #f8b400;
            color: #f8b400;
            font-weight: 600;
        }

        .btn-outline-primary:hover {
            background-color: #f8b400;
            color: white;
        }

        footer {
            background: url('https://images.unsplash.com/photo-1516321514428-6c6a2e8d0d21?crop=entropy&cs=tinysrgb&fit=max&ixid=MXwyMDg1MnwzNjV8c2VhY2h8N3x8fGZhdGVyaW5nJTIwb3V0ZG9vcnxlbnwwfHw%3D') center/cover no-repeat;
            background-size: cover;
            color: white;
            padding: 40px 0;
        }

        footer h5 {
            font-weight: 600;
            color: #f8b400;
        }

        footer p {
            margin-bottom: 0.3rem;
            font-weight: 300;
        }

        .navbar {
            background-color: #222222;
        }

        .navbar-brand {
            font-weight: bold;
            font-size: 2rem;
            color: #f8b400;
        }

        .navbar-nav .nav-link {
            color: #f8b400 !important;
            font-size: 1.1rem;
            font-weight: 500;
            margin-left: 20px;
        }

        .navbar-nav .nav-link:hover {
            color: white !important;
            text-decoration: underline;
        }

        .navbar-toggler-icon {
            background-color: #f8b400;
        }

    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php" style="color:white">HOME</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="employee/login.php" style="color:white">FIND JOBS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="company/login.php" style="color:white">COMPANY LOGIN </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="company/about.php" style="color:white">ABOUT </a>
                    </li>
                    
                    
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section with Background Carousel -->
    <section class="hero-section">
        <div id="carouselExampleAutoplaying" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">
            <div class="carousel-inner">
                <div class="carousel-item active" style="background-image: url('https://images.unsplash.com/photo-1562577300-d375c15aeb34?crop=entropy&cs=tinysrgb&fit=max&ixid=MXwyMDg1MnwzNjV8c2VhY2h8Mnw0fGluZG9vcmdlcyUyQ3Byb2Zlc3Npb25hbHxlbnwwfHw%3D');">
                    <div class="overlay"></div>
                    <div class="hero-text">
                        <h1 class="display-4 mb-4" style="color:white">Find Your Dream Job Today</h1>
                        <p class="lead mb-4" style="color:yellow">Connecting talented Professionals with top Opportunities</p>
                    </div>
                </div>
                <div class="carousel-item" style="background-image: url('https://images.unsplash.com/photo-1594728901881-68e03a6bbfd2?crop=entropy&cs=tinysrgb&fit=max&ixid=MXwyMDg1MnwzNjV8c2VhY2h8Mnx8fGJlYXV0aWZ1bCB3b3JrJTIwc3RhZmZ8ZW58MHx8fHw%3D');">
                    <div class="overlay"></div>
                    <div class="hero-text">
                        <h1 class="display-4 mb-4">Find Your Dream Job Today</h1>
                        <p class="lead mb-4">Connecting talented Professionals with top Opportunities</p>
                    </div>
                </div>
                <div class="carousel-item" style="background-image: url('https://images.unsplash.com/photo-1584744355020-1fa7f39ff456?crop=entropy&cs=tinysrgb&fit=max&ixid=MXwyMDg1MnwzNjV8c2VhY2h8Mnx8fGpvaG5nb2xlc3xlbnwwfHw%3D');">
                    <div class="overlay"></div>
                    <div class="hero-text">
                        <h1 class="display-4 mb-4 " >Find Your Dream Job Today</h1>
                        <p class="lead mb-4">Connecting talented Professionals with top Opportunities</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="login-section">
        <div class="container">
            <?php echo displayMessage(); ?>
            <div class="row justify-content-center">
                <!-- Job Seekers -->
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h4>Job Seekers</h4>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="employee/login.php" class="btn btn-primary">Login</a>
                                <a href="employee/register.php" class="btn btn-outline-primary">Register</a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Employers -->
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h4 >Company</h4>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <a href="company/login.php" class="btn btn-primary">Login</a>
                                <a href="company/register.php" class="btn btn-outline-primary">Register</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <footer class="text-light py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5 style="color:blue">About Job Portal</h5>
                    <p style="color:#222222">Connecting talented Professionals with amazing Opportunities worldwide.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <h5 style="color:blue">Contact Us</h5>
                    <p style="color:#222222">Email: deepak@gmail.com</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
