<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

$conn = connectDB();
$employee_id = $_SESSION['user_id'];

// Fetch notifications
$stmt = $conn->prepare("SELECT n.message, n.created_at FROM notifications n WHERE n.employee_id = ? ORDER BY n.created_at DESC");
if (!$stmt) {
    die('Query preparation failed: ' . $conn->error);
}
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$result = $stmt->get_result();

$conn->close();

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Notifications</h2>
        <?php if ($result->num_rows > 0): ?>
            <ul class="list-group">
                <?php while ($notification = $result->fetch_assoc()): ?>
                    <li class="list-group-item">
                        <strong><?php echo date('M d, Y', strtotime($notification['created_at'])); ?>:</strong> <?php echo htmlspecialchars($notification['message']); ?>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <div class="alert alert-warning">No notifications found.</div>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>