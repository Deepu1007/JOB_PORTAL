<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    header('Location: login.php');
    exit;
}

$conn = connectDB();
$employee_id = $_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $resignation_reason = sanitizeInput($_POST['resignation_reason']);
    
    // Start transaction to ensure all updates happen or none
    $conn->begin_transaction();
    
    // Update employee status
    $query1 = "UPDATE employees SET status='resigned', resignation_reason=? WHERE employee_id=?";
    $stmt1 = $conn->prepare($query1);
    
    // Update employment record status to Terminated
    $query2 = "UPDATE employment_records SET status='Terminated', end_date=CURRENT_DATE WHERE employee_id=? AND status='Active'";
    $stmt2 = $conn->prepare($query2);
    
    // Get employee name and company information for notification
    $query3 = "SELECT e.first_name, e.last_name, er.company_id 
              FROM employees e 
              JOIN employment_records er ON e.employee_id = er.employee_id 
              WHERE e.employee_id = ? AND er.status = 'Active'";
    $stmt3 = $conn->prepare($query3);
    
    if ($stmt1 && $stmt2 && $stmt3) {
        $stmt1->bind_param('si', $resignation_reason, $employee_id);
        $stmt2->bind_param('i', $employee_id);
        $stmt3->bind_param('i', $employee_id);
        
        $success1 = $stmt1->execute();
        $success2 = $stmt2->execute();
        $stmt3->execute();
        $employee_info = $stmt3->get_result()->fetch_assoc();
        
        // Create notification for company
        $success3 = false;
        if ($employee_info) {
            $company_id = $employee_info['company_id'];
            $employee_name = $employee_info['first_name'] . ' ' . $employee_info['last_name'];
            $notification_message = "Employee {$employee_name} has resigned. Reason: {$resignation_reason}";
            
            // Insert notification for company
            $query4 = "INSERT INTO notifications (company_id, employee_id, message, created_at) VALUES (?, ?, ?, NOW())";
            $stmt4 = $conn->prepare($query4);
            if ($stmt4) {
                $stmt4->bind_param('iis', $company_id, $employee_id, $notification_message);
                $success3 = $stmt4->execute();
            }
        }
        
        if ($success1 && $success2 && ($employee_info ? $success3 : true)) {
            $conn->commit();
            $_SESSION['message'] = 'Your resignation has been processed. You are no longer employed with the company.';
            $_SESSION['message_type'] = 'success';
            header('Location: dashboard.php');
            exit();
        } else {
            $conn->rollback();
            $message = 'Error processing resignation: ' . $conn->error;
        }
    } else {
        $message = 'Prepare failed: ' . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resign from Job</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center">Resign from Your Job</h2>

    <?php if (!empty($message)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <form method="POST" class="mt-4">
        <div class="mb-3">
            <label for="resignation_reason" class="form-label">Reason for Resignation</label>
            <textarea class="form-control" id="resignation_reason" name="resignation_reason" rows="4" required></textarea>
        </div>
        <button type="submit" class="btn btn-danger">Submit Resignation</button>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
