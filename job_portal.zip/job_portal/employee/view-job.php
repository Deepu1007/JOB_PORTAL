<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

if (!isset($_GET['id'])) {
    redirectWithMessage('search-jobs.php', 'Invalid job ID', 'error');
}

$conn = connectDB();
$job_id = (int)$_GET['id'];
$employee_id = $_SESSION['user_id'];

// Get job details with company information
$stmt = $conn->prepare("SELECT jp.*, c.company_name, c.location as company_location, c.website, c.email as company_email 
                       FROM job_postings jp 
                       JOIN companies c ON jp.company_id = c.company_id 
                       WHERE jp.job_id = ? AND jp.status = 'Open'");
$stmt->bind_param("i", $job_id);
$stmt->execute();
$job = $stmt->get_result()->fetch_assoc();

if (!$job) {
    redirectWithMessage('search-jobs.php', 'Job not found or no longer available', 'error');
}

// Check if already applied
$stmt = $conn->prepare("SELECT * FROM job_applications WHERE job_id = ? AND employee_id = ?");
$stmt->bind_param("ii", $job_id, $employee_id);
$stmt->execute();
$existing_application = $stmt->get_result()->fetch_assoc();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($job['title']); ?> - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="search-jobs.php">Search Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="my-applications.php">My Applications</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-5">
        <?php echo displayMessage(); ?>

        <div class="row">
            <div class="col-md-8">
                <h1 class="mb-4"><?php echo htmlspecialchars($job['title']); ?></h1>
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Job Description</h5>
                        <p class="card-text"><?php echo nl2br(htmlspecialchars($job['description'])); ?></p>

                        <h5 class="card-title mt-4">Requirements</h5>
                        <p class="card-text"><?php echo nl2br(htmlspecialchars($job['requirements'])); ?></p>

                        <div class="row mt-4">
                            <div class="col-md-6">
                                <h5 class="card-title">Job Details</h5>
                                <ul class="list-unstyled">
                                    <li><strong>Location:</strong> <?php echo htmlspecialchars($job['location']); ?></li>
                                    <li><strong>Job Type:</strong> <?php echo htmlspecialchars($job['job_type']); ?></li>
                                    <li><strong>Salary Range:</strong> <?php echo htmlspecialchars($job['salary_range']); ?></li>
                                    <li><strong>Posted:</strong> <?php echo date('M d, Y', strtotime($job['created_at'])); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Company Information</h5>
                        <h6 class="card-subtitle mb-2 text-muted"><?php echo htmlspecialchars($job['company_name']); ?></h6>
                        <p class="card-text">
                            <strong>Location:</strong> <?php echo htmlspecialchars($job['company_location']); ?><br>
                            <?php if ($job['website']): ?>
                            <strong>Website:</strong> <a href="<?php echo htmlspecialchars($job['website']); ?>" target="_blank"><?php echo htmlspecialchars($job['website']); ?></a><br>
                            <?php endif; ?>
                            <strong>Email:</strong> <?php echo htmlspecialchars($job['company_email']); ?>
                        </p>
                        
                        <?php if (!$existing_application): ?>
                        <form action="apply-job.php" method="POST" class="mt-3">
                            <input type="hidden" name="job_id" value="<?php echo $job_id; ?>">
                            <button type="submit" class="btn btn-primary w-100">Apply Now</button>
                        </form>
                        <?php else: ?>
                        <div class="alert alert-info mb-0">
                            You have already applied for this position on <?php echo date('M d, Y', strtotime($existing_application['applied_at'])); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>