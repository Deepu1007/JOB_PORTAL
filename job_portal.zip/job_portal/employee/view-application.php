<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: my-applications.php');
    exit;
}

$conn = connectDB();
$employee_id = $_SESSION['user_id'];
$application_id = $_GET['id'];

// Get application details with job and company information
$stmt = $conn->prepare("SELECT ja.*, jp.title as job_title, jp.description as job_description, 
                        jp.requirements, jp.salary_range, jp.location,
                        c.company_name
                        FROM job_applications ja 
                        JOIN job_postings jp ON ja.job_id = jp.job_id 
                        JOIN companies c ON jp.company_id = c.company_id 
                        WHERE ja.application_id = ? AND ja.employee_id = ?");
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}
$stmt->bind_param("ii", $application_id, $employee_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $conn->close();
    header('Location: my-applications.php');
    exit;
}

$application = $result->fetch_assoc();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Application - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Job Portal</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="search-jobs.php">Search Jobs</a></li>
                    <li class="nav-item"><a class="nav-link" href="my-applications.php">My Applications</a></li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
                    <li class="nav-item"><a class="nav-link" href="resign.php">Resign</a></li>
                    <li class="nav-item"><a class="nav-link" href="../logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="mb-4">Application Details</h1>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Job Title: <?php echo htmlspecialchars($application['job_title']); ?></h5>
                <h6 class="card-subtitle mb-2 text-muted">Company: <?php echo htmlspecialchars($application['company_name']); ?></h6>
                <p class="card-text">Description: <?php echo htmlspecialchars($application['job_description']); ?></p>
                <p class="card-text">Requirements: <?php echo htmlspecialchars($application['requirements']); ?></p>
                <p class="card-text">Location: <?php echo htmlspecialchars($application['location']); ?></p>
                <p class="card-text">Salary Range: <?php echo htmlspecialchars($application['salary_range']); ?></p>
                <p class="card-text">Status: <?php echo htmlspecialchars($application['status']); ?></p>
                <p class="card-text">Applied On: <?php echo date('M d, Y', strtotime($application['applied_at'])); ?></p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>