
<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    header('Location: login.php');
    exit;
}

$conn = connectDB();
$employee_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM employees WHERE employee_id = ?");
if (!$stmt) die("Prepare failed: " . $conn->error);
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$employee = $stmt->get_result()->fetch_assoc();

$stmt = $conn->prepare("SELECT ja.*, jp.title, jp.salary_range, c.company_name 
                       FROM job_applications ja 
                       JOIN job_postings jp ON ja.job_id = jp.job_id 
                       JOIN companies c ON jp.company_id = c.company_id 
                       WHERE ja.employee_id = ? 
                       ORDER BY ja.applied_at DESC LIMIT 5");
if (!$stmt) die("Prepare failed: " . $conn->error);
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$recent_applications = $stmt->get_result();

$stmt = $conn->prepare("SELECT jp.*, c.company_name 
                       FROM job_postings jp 
                       JOIN companies c ON jp.company_id = c.company_id 
                       WHERE jp.status = 'Open' 
                       ORDER BY jp.created_at DESC LIMIT 10");
if (!$stmt) die("Prepare failed: " . $conn->error);
$stmt->execute();
$latest_jobs = $stmt->get_result();

$stmt = $conn->prepare("SELECT er.*, c.company_name, jp.title AS job_title 
                       FROM employment_records er 
                       JOIN companies c ON er.company_id = c.company_id 
                       JOIN job_postings jp ON er.job_id = jp.job_id 
                       WHERE er.employee_id = ? AND er.status = 'Active'");
if (!$stmt) die("Prepare failed: " . $conn->error);
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$current_employment = $stmt->get_result()->fetch_assoc();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Dashboard - Job Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .navbar {
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .dashboard-header {
            background: linear-gradient(to right, #0066cc, #004080);
            color: white;
            padding: 30px 0;
            margin-bottom: 40px;
            border-bottom: 3px solid #003366;
        }

        .dashboard-header h1 {
            font-size: 2.2rem;
            font-weight: 500;
        }

        .card {
            border: none;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            border-radius: 12px;
        }

        .card-header {
            background-color: #f0f4f8;
            font-weight: 600;
            border-bottom: 1px solid #dee2e6;
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;
        }

        .job-card {
            border: 1px solid #dee2e6;
            border-radius: 10px;
            background-color: #ffffff;
            transition: all 0.3s ease;
        }

        .job-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        }

        .list-group-item {
            border: none;
            border-bottom: 1px solid #f0f0f0;
        }

        .alert-info {
            background-color: #e8f4fc;
            border: 1px solid #b6e0fe;
            color: #055160;
            border-radius: 10px;
        }

        .btn-outline-primary, .btn-primary {
            border-radius: 30px;
            font-weight: 500;
        }

        .btn-outline-primary:hover {
            background-color: #0066cc;
            color: white;
        }

        .btn-primary {
            background-color: #0066cc;
            border-color: #005cbf;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #004999;
        }

        .badge {
            font-size: 0.75rem;
            padding: 0.35em 0.6em;
            border-radius: 0.5rem;
        }

        a {
            text-decoration: none;
        }

        .card-title, .card-subtitle {
            margin-bottom: 0.25rem;
        }

        .card-text {
            font-size: 0.9rem;
            color: #333;
        }

        .list-group-item:hover {
            background-color: #f8f9fa;
        }
    </style>
</head>
<body>
<!-- THE REST OF YOUR HTML STARTS HERE AND REMAINS EXACTLY AS YOU POSTED -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Dashboard - Job Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .dashboard-header {
            background-color: #f8f9fa;
            padding: 20px 0;
            margin-bottom: 30px;
        }
        .job-card {
            transition: transform 0.2s;
        }
        .job-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Employee Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="search-jobs.php">Search Jobs</a></li>
                <li class="nav-item"><a class="nav-link" href="my-applications.php">My Applications</a></li>
                <li class="nav-item"><a class="nav-link" href="saved-jobs.php">Saved Jobs</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
                <li class="nav-item"><a class="nav-link" href="resign.php">Resign</a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="dashboard-header">
    <div class="container">
        <h1>Welcome, <?php echo htmlspecialchars(isset($employee['first_name']) ? $employee['first_name'] : 'Employee'); ?>!</h1>
    </div>
</div>

<div class="container mb-5">
    <?php if (function_exists('displayMessage')) echo displayMessage(); ?>

    <?php if ($current_employment): ?>
        <div class="alert alert-info">
            <h5>Current Employment</h5>
            <p>You are currently employed at <strong><?php echo htmlspecialchars($current_employment['company_name']); ?></strong> as <strong><?php echo htmlspecialchars($current_employment['job_title']); ?></strong></p>
            <small>Started: <?php echo date('M d, Y', strtotime($current_employment['start_date'])); ?></small>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Latest Job Opportunities</h5>
                </div>
                <div class="card-body">
                    <?php if ($latest_jobs->num_rows > 0): ?>
                        <?php while ($job = $latest_jobs->fetch_assoc()): ?>
                            <div class="card mb-3 job-card">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo htmlspecialchars($job['title']); ?></h5>
                                    <h6 class="card-subtitle mb-2 text-muted"><?php echo htmlspecialchars($job['company_name']); ?></h6>
                                    <p class="card-text"><?php echo htmlspecialchars(substr($job['description'], 0, 150)) . '...'; ?></p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <span class="badge bg-primary me-2"><?php echo htmlspecialchars($job['job_type']); ?></span>
                                            <span class="badge bg-secondary me-2"><?php echo htmlspecialchars($job['location']); ?></span>
                                            <span class="badge bg-info"><?php echo htmlspecialchars($job['salary_range']); ?></span>
                                        </div>
                                        <a href="view-job.php?id=<?php echo $job['job_id']; ?>" class="btn btn-outline-primary btn-sm">View Details</a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                        <div class="text-center mt-3">
                            <a href="search-jobs.php" class="btn btn-primary">View All Jobs</a>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No job postings available at the moment.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header"><h5 class="mb-0">My Recent Applications</h5></div>
                <div class="card-body">
                    <?php if ($recent_applications->num_rows > 0): ?>
                        <div class="list-group">
                            <?php while ($application = $recent_applications->fetch_assoc()): ?>
                                <a href="view-application.php?id=<?php echo $application['application_id']; ?>" class="list-group-item list-group-item-action">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1"><?php echo htmlspecialchars($application['title']); ?></h6>
                                        <small class="text-<?php echo $application['status'] === 'Pending' ? 'warning' : 'success'; ?>">
                                            <?php echo htmlspecialchars($application['status']); ?>
                                        </small>
                                    </div>
                                    <p class="mb-1"><?php echo htmlspecialchars($application['company_name']); ?></p>
                                    <small>Applied: <?php echo date('M d, Y', strtotime($application['applied_at'])); ?></small>
                                </a>
                            <?php endwhile; ?>
                        </div>
                        <div class="text-center mt-3">
                            <a href="my-applications.php" class="btn btn-outline-primary">View All Applications</a>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">No applications yet.</p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <div class="card-header"><h5 class="mb-0">Quick Profile</h5></div>
                <div class="card-body">
                    <div class="mb-3">
                        <h6>Skills</h6>
                        <p><?php echo htmlspecialchars(!empty($employee['skills']) ? $employee['skills'] : 'No skills listed'); ?></p>
                    </div>
                    <div class="mb-3">
                        <h6>Experience</h6>
                        <p><?php echo htmlspecialchars(!empty($employee['experience']) ? $employee['experience'] : 'No experience listed'); ?></p>
                    </div>
                    <div class="mb-3">
                        <h6>Education</h6>
                        <p><?php echo htmlspecialchars(!empty($employee['education']) ? $employee['education'] : 'No education listed'); ?></p>
                    </div>
                    <div class="text-center">
                        <a href="profile.php" class="btn btn-outline-primary">Update Profile</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
