<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['job_id'])) {
    redirectWithMessage('search-jobs.php', 'Invalid request', 'error');
}

$conn = connectDB();
$job_id = (int)$_POST['job_id'];
$employee_id = $_SESSION['user_id'];

// Verify job exists and is open
$stmt = $conn->prepare("SELECT job_id FROM job_postings WHERE job_id = ? AND status = 'Open'");
$stmt->bind_param("i", $job_id);
$stmt->execute();
$job = $stmt->get_result()->fetch_assoc();

if (!$job) {
    redirectWithMessage('search-jobs.php', 'Job not found or no longer available', 'error');
}

// Check if already applied
$stmt = $conn->prepare("SELECT application_id FROM job_applications WHERE job_id = ? AND employee_id = ?");
$stmt->bind_param("ii", $job_id, $employee_id);
$stmt->execute();

if ($stmt->get_result()->fetch_assoc()) {
    redirectWithMessage('view-job.php?id=' . $job_id, 'You have already applied for this position', 'warning');
}

// Insert application
$stmt = $conn->prepare("INSERT INTO job_applications (job_id, employee_id, status) VALUES (?, ?, 'Pending')");
$stmt->bind_param("ii", $job_id, $employee_id);

if ($stmt->execute()) {
    redirectWithMessage('view-job.php?id=' . $job_id, 'Application submitted successfully!', 'success');
} else {
    redirectWithMessage('view-job.php?id=' . $job_id, 'Failed to submit application. Please try again.', 'error');
}

$conn->close();