<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    header('Location: login.php');
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    redirectWithMessage('search-jobs.php', 'Invalid job ID', 'danger');
}

$conn = connectDB();
$employee_id = $_SESSION['user_id'];
$job_id = (int)$_GET['id'];

// Check if the job exists and is open
$stmt = $conn->prepare("SELECT job_id FROM job_postings WHERE job_id = ? AND status = 'Open'");
$stmt->bind_param("i", $job_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $conn->close();
    redirectWithMessage('search-jobs.php', 'Job not found or no longer available', 'danger');
}

// Check if saved_jobs table exists, if not create it
$result = $conn->query("SHOW TABLES LIKE 'saved_jobs'");
if ($result->num_rows == 0) {
    $sql = "CREATE TABLE saved_jobs (
        id INT PRIMARY KEY AUTO_INCREMENT,
        employee_id INT NOT NULL,
        job_id INT NOT NULL,
        saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE,
        FOREIGN KEY (job_id) REFERENCES job_postings(job_id) ON DELETE CASCADE,
        UNIQUE KEY unique_saved_job (employee_id, job_id)
    )";
    
    if ($conn->query($sql) === FALSE) {
        $conn->close();
        redirectWithMessage('view-job.php?id=' . $job_id, 'Error creating saved jobs table', 'danger');
    }
}

// Check if job is already saved
$stmt = $conn->prepare("SELECT id FROM saved_jobs WHERE employee_id = ? AND job_id = ?");
$stmt->bind_param("ii", $employee_id, $job_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Job already saved, remove it (toggle functionality)
    $stmt = $conn->prepare("DELETE FROM saved_jobs WHERE employee_id = ? AND job_id = ?");
    $stmt->bind_param("ii", $employee_id, $job_id);
    
    if ($stmt->execute()) {
        $conn->close();
        redirectWithMessage('view-job.php?id=' . $job_id, 'Job removed from saved list', 'success');
    } else {
        $conn->close();
        redirectWithMessage('view-job.php?id=' . $job_id, 'Error removing job from saved list', 'danger');
    }
} else {
    // Save the job
    $stmt = $conn->prepare("INSERT INTO saved_jobs (employee_id, job_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $employee_id, $job_id);
    
    if ($stmt->execute()) {
        $conn->close();
        redirectWithMessage('view-job.php?id=' . $job_id, 'Job saved successfully', 'success');
    } else {
        $conn->close();
        redirectWithMessage('view-job.php?id=' . $job_id, 'Error saving job', 'danger');
    }
}