<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

$conn = connectDB();
$employee_id = $_SESSION['user_id'];

// Initialize search parameters
$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
$location = isset($_GET['location']) ? sanitizeInput($_GET['location']) : '';
$job_type = isset($_GET['job_type']) ? sanitizeInput($_GET['job_type']) : '';
$salary_min = isset($_GET['salary_min']) ? sanitizeInput($_GET['salary_min']) : '';
$salary_max = isset($_GET['salary_max']) ? sanitizeInput($_GET['salary_max']) : '';

// Build the query
$query = "SELECT jp.*, c.company_name, c.location as company_location 
          FROM job_postings jp 
          JOIN companies c ON jp.company_id = c.company_id 
          WHERE jp.status = 'Open'";
$params = [];
$types = '';

if (!empty($search)) {
    $query .= " AND (jp.title LIKE ? OR jp.description LIKE ? OR jp.requirements LIKE ?)";
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $types .= 'sss';
}

if (!empty($location)) {
    $query .= " AND jp.location LIKE ?";
    $params[] = "%$location%";
    $types .= 's';
}

if (!empty($job_type)) {
    $query .= " AND jp.job_type = ?";
    $params[] = $job_type;
    $types .= 's';
}

$query .= " ORDER BY jp.created_at DESC";

// Prepare and execute the query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$jobs = $stmt->get_result();

// Get all unique locations for filter
$locations_query = "SELECT DISTINCT location FROM job_postings WHERE location IS NOT NULL AND location != ''";
$locations_result = $conn->query($locations_query);
$locations = [];
while ($row = $locations_result->fetch_assoc()) {
    $locations[] = $row['location'];
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Jobs - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .search-section {
            background-color: #f8f9fa;
            padding: 30px 0;
            margin-bottom: 30px;
        }
        .job-card {
            transition: transform 0.2s;
            margin-bottom: 20px;
        }
        .job-card:hover {
            transform: translateY(-5px);
        }
        .filters {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Employee Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="search-jobs.php">Search Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="my-applications.php">My Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="saved-jobs.php">Saved Jobs</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="search-section">
        <div class="container">
            <h2 class="mb-4">Find Your Dream Job</h2>
            <form method="GET" action="" class="row g-3">
                <div class="col-md-4">
                    <input type="text" class="form-control" name="search" placeholder="Search jobs..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-3">
                    <input type="text" class="form-control" name="location" placeholder="Location" value="<?php echo htmlspecialchars($location); ?>">
                </div>
                <div class="col-md-3">
                    <select class="form-select" name="job_type">
                        <option value="">All Job Types</option>
                        <option value="Full-time" <?php echo $job_type === 'Full-time' ? 'selected' : ''; ?>>Full-time</option>
                        <option value="Part-time" <?php echo $job_type === 'Part-time' ? 'selected' : ''; ?>>Part-time</option>
                        <option value="Contract" <?php echo $job_type === 'Contract' ? 'selected' : ''; ?>>Contract</option>
                        <option value="Internship" <?php echo $job_type === 'Internship' ? 'selected' : ''; ?>>Internship</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Search</button>
                </div>
            </form>
        </div>
    </section>

    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="filters mb-4">
                    <h5>Filters</h5>
                    <hr>
                    <form method="GET" action="">
                        <div class="mb-3">
                            <label class="form-label">Salary Range</label>
                            <div class="input-group mb-2">
                                <span class="input-group-text">$</span>
                                <input type="number" class="form-control" name="salary_min" placeholder="Min" value="<?php echo htmlspecialchars($salary_min); ?>">
                            </div>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" class="form-control" name="salary_max" placeholder="Max" value="<?php echo htmlspecialchars($salary_max); ?>">
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Job Type</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="Full-time" id="fullTime">
                                <label class="form-check-label" for="fullTime">Full-time</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="Part-time" id="partTime">
                                <label class="form-check-label" for="partTime">Part-time</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="Contract" id="contract">
                                <label class="form-check-label" for="contract">Contract</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="Internship" id="internship">
                                <label class="form-check-label" for="internship">Internship</label>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Location</label>
                            <select class="form-select" name="location">
                                <option value="">All Locations</option>
                                <?php foreach ($locations as $loc): ?>
                                    <option value="<?php echo htmlspecialchars($loc); ?>" <?php echo $location === $loc ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($loc); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn btn-primary w-100">Apply Filters</button>
                    </form>
                </div>
            </div>
            
            <div class="col-md-9">
                <h4 class="mb-4"><?php echo $jobs->num_rows; ?> Jobs Found</h4>
                
                <?php if ($jobs->num_rows > 0): ?>
                    <?php while ($job = $jobs->fetch_assoc()): ?>
                        <div class="card job-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h5 class="card-title"><?php echo htmlspecialchars($job['title']); ?></h5>
                                        <h6 class="card-subtitle mb-2 text-muted"><?php echo htmlspecialchars($job['company_name']); ?></h6>
                                    </div>
                                    <span class="badge bg-primary"><?php echo $job['job_type']; ?></span>
                                </div>
                                
                                <p class="card-text"><?php echo htmlspecialchars(substr($job['description'], 0, 200)) . '...'; ?></p>
                                
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="me-3"><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($job['location']); ?></span>
                                        <span class="me-3"><i class="fas fa-money-bill-wave"></i> <?php echo htmlspecialchars($job['salary_range']); ?></span>
                                        <span><i class="fas fa-clock"></i> Posted <?php echo date('M d, Y', strtotime($job['created_at'])); ?></span>
                                    </div>
                                    <div>
                                        <a href="view-job.php?id=<?php echo $job['job_id']; ?>" class="btn btn-outline-primary">View Details</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="alert alert-info">
                        <p class="mb-0">No jobs found matching your criteria. Try adjusting your search filters.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>