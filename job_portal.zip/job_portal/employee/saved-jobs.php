<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    header('Location: login.php');
    exit;
}

$conn = connectDB();
$employee_id = $_SESSION['user_id'];
$message = '';
$message_type = '';

// Check if saved_jobs table exists, if not create it
$result = $conn->query("SHOW TABLES LIKE 'saved_jobs'");
if ($result->num_rows == 0) {
    $sql = "CREATE TABLE saved_jobs (
        id INT PRIMARY KEY AUTO_INCREMENT,
        employee_id INT NOT NULL,
        job_id INT NOT NULL,
        saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE,
        FOREIGN KEY (job_id) REFERENCES job_postings(job_id) ON DELETE CASCADE,
        UNIQUE KEY unique_saved_job (employee_id, job_id)
    )";
    
    if ($conn->query($sql) === FALSE) {
        die("Error creating saved_jobs table: " . $conn->error);
    }
}

// Handle job removal from saved list
if (isset($_GET['remove']) && is_numeric($_GET['remove'])) {
    $job_id = (int)$_GET['remove'];
    
    $stmt = $conn->prepare("DELETE FROM saved_jobs WHERE employee_id = ? AND job_id = ?");
    $stmt->bind_param("ii", $employee_id, $job_id);
    
    if ($stmt->execute()) {
        $message = "Job removed from saved list.";
        $message_type = "success";
    } else {
        $message = "Error removing job: " . $conn->error;
        $message_type = "danger";
    }
}

// Get saved jobs with job and company details
$stmt = $conn->prepare("SELECT sj.*, jp.title, jp.location, jp.salary_range, jp.job_type, jp.status,
                       c.company_name, jp.created_at
                       FROM saved_jobs sj
                       JOIN job_postings jp ON sj.job_id = jp.job_id
                       JOIN companies c ON jp.company_id = c.company_id
                       WHERE sj.employee_id = ?
                       ORDER BY sj.saved_at DESC");

if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("i", $employee_id);
$stmt->execute();
$saved_jobs = $stmt->get_result();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Saved Jobs - Job Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="dashboard.php">Job Portal</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="search-jobs.php">Search Jobs</a></li>
                <li class="nav-item"><a class="nav-link" href="my-applications.php">My Applications</a></li>
                <li class="nav-item"><a class="nav-link active" href="saved-jobs.php">Saved Jobs</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="profile.php">Profile</a></li>
                <li class="nav-item"><a class="nav-link" href="resign.php">Resign</a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h1>Saved Jobs</h1>
    
    <?php if ($message): ?>
        <div class="alert alert-<?php echo $message_type; ?>"><?php echo $message; ?></div>
    <?php endif; ?>
    
    <?php if ($saved_jobs->num_rows > 0): ?>
        <div class="row mt-4">
            <?php while ($job = $saved_jobs->fetch_assoc()): ?>
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h5 class="card-title mb-0"><?php echo htmlspecialchars($job['title']); ?></h5>
                                <span class="badge bg-<?php echo $job['status'] === 'Open' ? 'success' : 'secondary'; ?>">
                                    <?php echo htmlspecialchars($job['status']); ?>
                                </span>
                            </div>
                            <h6 class="card-subtitle mb-2 text-muted"><?php echo htmlspecialchars($job['company_name']); ?></h6>
                            <p class="card-text">
                                <i class="fas fa-map-marker-alt me-2"></i><?php echo htmlspecialchars($job['location']); ?><br>
                                <i class="fas fa-money-bill-wave me-2"></i><?php echo htmlspecialchars($job['salary_range']); ?><br>
                                <i class="fas fa-briefcase me-2"></i><?php echo htmlspecialchars($job['job_type']); ?>
                            </p>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">Saved on <?php echo date('M d, Y', strtotime($job['saved_at'])); ?></small>
                                <div>
                                    <a href="view-job.php?id=<?php echo $job['job_id']; ?>" class="btn btn-sm btn-primary">View Details</a>
                                    <a href="saved-jobs.php?remove=<?php echo $job['job_id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Remove this job from saved list?')">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info mt-4">
            <p>You haven't saved any jobs yet.</p>
            <a href="search-jobs.php" class="btn btn-primary mt-2">Browse Jobs</a>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>