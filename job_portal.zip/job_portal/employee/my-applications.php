<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    header('Location: login.php');
    exit;
}

$conn = connectDB();
$employee_id = $_SESSION['user_id'];

// Get employee applications
$stmt = $conn->prepare("SELECT ja.*, jp.title, jp.salary_range, c.company_name 
                       FROM job_applications ja 
                       JOIN job_postings jp ON ja.job_id = jp.job_id 
                       JOIN companies c ON jp.company_id = c.company_id 
                       WHERE ja.employee_id = ? 
                       ORDER BY ja.applied_at DESC");
if (!$stmt) die("Prepare failed: " . $conn->error);
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$applications = $stmt->get_result();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Applications - Job Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1>My Applications</h1>
    <?php if ($applications->num_rows > 0): ?>
        <div class="list-group">
            <?php while ($application = $applications->fetch_assoc()): ?>
                <a href="view-application.php?id=<?php echo $application['application_id']; ?>" class="list-group-item list-group-item-action">
                    <div class="d-flex w-100 justify-content-between">
                        <h6 class="mb-1"><?php echo htmlspecialchars($application['title']); ?></h6>
                        <small class="text-<?php echo $application['status'] === 'Pending' ? 'warning' : 'success'; ?>">
                            <?php echo htmlspecialchars($application['status']); ?>
                        </small>
                    </div>
                    <p class="mb-1"><?php echo htmlspecialchars($application['company_name']); ?></p>
                    <small>Applied: <?php echo date('M d, Y', strtotime($application['applied_at'])); ?></small>
                </a>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <p class="text-muted">No applications yet.</p>
    <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>