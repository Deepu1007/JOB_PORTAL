<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'employee') {
    header('Location: login.php');
    exit;
}

$conn = connectDB();
$employee_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Get employee info
$stmt = $conn->prepare("SELECT * FROM employees WHERE employee_id = ?");
if (!$stmt) die("Prepare failed: " . $conn->error);
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$employee = $stmt->get_result()->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = sanitizeInput($_POST['first_name']);
    $last_name = sanitizeInput($_POST['last_name']);
    $skills = sanitizeInput($_POST['skills']);
    $experience = sanitizeInput($_POST['experience']);
    $education = sanitizeInput($_POST['education']);
    $phone = sanitizeInput(isset($_POST['phone']) ? $_POST['phone'] : '');
    $address = sanitizeInput(isset($_POST['address']) ? $_POST['address'] : '');

    // Update employee information
    $stmt = $conn->prepare("UPDATE employees SET first_name = ?, last_name = ?, skills = ?, experience = ?, education = ?, phone = ?, address = ? WHERE employee_id = ?");
    if (!$stmt) {
        $error = "Prepare failed: " . $conn->error;
    } else {
        $stmt->bind_param("sssssssi", $first_name, $last_name, $skills, $experience, $education, $phone, $address, $employee_id);
        if ($stmt->execute()) {
            $success = "Profile updated successfully!";

            // Refresh employee data
            $stmt = $conn->prepare("SELECT * FROM employees WHERE employee_id = ?");
            $stmt->bind_param("i", $employee_id);
            $stmt->execute();
            $employee = $stmt->get_result()->fetch_assoc();
        } else {
            $error = "Error updating profile: " . $stmt->error;
        }
    }

    // Handle resume upload if file is selected
    if (isset($_FILES['resume']) && $_FILES['resume']['error'] == 0) {
        $allowed = array('pdf', 'doc', 'docx');
        $filename = $_FILES['resume']['name'];
        $ext = pathinfo($filename, PATHINFO_EXTENSION);

        if (in_array(strtolower($ext), $allowed)) {
            $new_filename = 'resume_' . $employee_id . '_' . time() . '.' . $ext;
            $upload_dir = '../uploads/resumes/';

            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $destination = $upload_dir . $new_filename;

            if (move_uploaded_file($_FILES['resume']['tmp_name'], $destination)) {
                $stmt = $conn->prepare("UPDATE employees SET resume_path = ? WHERE employee_id = ?");
                $stmt->bind_param("si", $destination, $employee_id);
                if ($stmt->execute()) {
                    $success .= " Resume uploaded successfully!";
                    $employee['resume_path'] = $destination;
                } else {
                    $error .= " Error updating resume in database.";
                }
            } else {
                $error .= " Error uploading resume file.";
            }
        } else {
            $error .= " Invalid resume file format. Allowed formats: PDF, DOC, DOCX.";
        }
    }
}

$conn->close();
?>

<!-- HTML PART REMAINS THE SAME -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Profile - Job Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="dashboard.php">Job Portal</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="search-jobs.php">Search Jobs</a></li>
                <li class="nav-item"><a class="nav-link" href="my-applications.php">My Applications</a></li>
                <li class="nav-item"><a class="nav-link" href="saved-jobs.php">Saved Jobs</a></li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="profile.php">Profile</a></li>
                <li class="nav-item"><a class="nav-link" href="resign.php">Resign</a></li>
                <li class="nav-item"><a class="nav-link" href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-5">
    <h1>My Profile</h1>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-body">
            <form method="post" enctype="multipart/form-data">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="first_name" class="form-label">First Name</label>
                        <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo htmlspecialchars($employee['first_name']); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="last_name" class="form-label">Last Name</label>
                        <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo htmlspecialchars($employee['last_name']); ?>" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" value="<?php echo htmlspecialchars($employee['email']); ?>" disabled>
                    <div class="form-text">Email cannot be changed.</div>
                </div>

                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="<?php echo htmlspecialchars(isset($employee['phone']) ? $employee['phone'] : ''); ?>">
                    </div>
                    <div class="col-md-6">
                        <label for="address" class="form-label">Address</label>
                        <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars(isset($employee['address']) ? $employee['address'] : ''); ?>">
                    </div>
                </div>

                <div class="mb-3">
                    <label for="skills" class="form-label">Skills</label>
                    <textarea class="form-control" id="skills" name="skills" rows="3"><?php echo htmlspecialchars($employee['skills']); ?></textarea>
                    <div class="form-text">List your key skills, separated by commas.</div>
                </div>

                <div class="mb-3">
                    <label for="experience" class="form-label">Work Experience</label>
                    <textarea class="form-control" id="experience" name="experience" rows="4"><?php echo htmlspecialchars($employee['experience']); ?></textarea>
                    <div class="form-text">Describe your work experience.</div>
                </div>

                <div class="mb-3">
                    <label for="education" class="form-label">Education</label>
                    <textarea class="form-control" id="education" name="education" rows="3"><?php echo htmlspecialchars($employee['education']); ?></textarea>
                    <div class="form-text">List your educational qualifications.</div>
                </div>

                <div class="mb-3">
                    <label for="resume" class="form-label">Resume</label>
                    <input class="form-control" type="file" id="resume" name="resume">
                    <div class="form-text">Upload your resume (PDF, DOC, DOCX).</div>
                    <?php if (!empty($employee['resume_path'])): ?>
                        <div class="mt-2">
                            <span class="badge bg-success">Resume uploaded</span>
                            <a href="<?php echo htmlspecialchars($employee['resume_path']); ?>" target="_blank" class="btn btn-sm btn-outline-primary ms-2">View Resume</a>
                        </div>
                    <?php endif; ?>
                </div>

                <button type="submit" class="btn btn-primary">Update Profile</button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
