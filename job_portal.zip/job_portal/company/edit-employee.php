<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

if (!isset($_GET['id'])) {
    redirectWithMessage('employees.php', 'Invalid employee ID', 'danger');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];
$employment_id = $_GET['id'];

// Get employee details
$stmt = $conn->prepare("
    SELECT er.position, er.salary, er.start_date, er.employee_id,
           e.first_name, e.last_name, e.email, e.phone, e.address, 
           e.skills, e.experience, e.education, 
           jp.title AS job_title 
    FROM employment_records er 
    JOIN employees e ON er.employee_id = e.employee_id 
    JOIN job_postings jp ON er.job_id = jp.job_id 
    WHERE er.record_id = ? AND er.company_id = ?
");

if (!$stmt) {
    die('Query preparation failed: ' . $conn->error);
}
$stmt->bind_param("ii", $employment_id, $company_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $conn->close();
    redirectWithMessage('employees.php', 'Employee not found', 'danger');
}

$employee = $result->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = isset($_POST['first_name']) ? $_POST['first_name'] : '';
    $last_name = isset($_POST['last_name']) ? $_POST['last_name'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $phone = isset($_POST['phone']) ? $_POST['phone'] : '';
    $address = isset($_POST['address']) ? $_POST['address'] : '';
    $position = isset($_POST['position']) ? $_POST['position'] : (isset($employee['position']) ? $employee['position'] : '');
    $salary = isset($_POST['salary']) ? $_POST['salary'] : (isset($employee['salary']) ? $employee['salary'] : 0);

    // Update employees table
    $stmt = $conn->prepare("UPDATE employees SET first_name = ?, last_name = ?, email = ?, phone = ?, address = ? WHERE employee_id = ?");
    if (!$stmt) {
        die('Update preparation failed (employees): ' . $conn->error);
    }
    $stmt->bind_param("sssssi", $first_name, $last_name, $email, $phone, $address, $employee['employee_id']);
    $stmt->execute();

    // Update employment_records table
    $stmt = $conn->prepare("UPDATE employment_records SET `position` = ?, salary = ? WHERE record_id = ? AND company_id = ?");
    if (!$stmt) {
        die('Update preparation failed (employment_records): ' . $conn->error);
    }
    $stmt->bind_param("sdii", $position, $salary, $employment_id, $company_id);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            redirectWithMessage('employees.php', 'Employee details updated successfully', 'success');
        } else {
            $error = 'No changes were made to the employee details';
        }
    } else {
        $error = 'Failed to update employee details: ' . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Employee - Job Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="dashboard.php">Company Dashboard</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="employees.php">Employees</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container my-4">
    <h2>Edit Employee Details</h2>
    <?php echo displayMessage(); ?>
    <?php if (isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">First Name</label>
                    <input type="text" class="form-control" name="first_name" value="<?php echo htmlspecialchars($employee['first_name']); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Last Name</label>
                    <input type="text" class="form-control" name="last_name" value="<?php echo htmlspecialchars($employee['last_name']); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($employee['email']); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Phone</label>
                    <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($employee['phone']); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Address</label>
                    <input type="text" class="form-control" name="address" value="<?php echo htmlspecialchars($employee['address']); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Position</label>
                    <input type="text" class="form-control" name="position" value="<?php echo htmlspecialchars($employee['position']); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Salary</label>
                    <input type="number" class="form-control" name="salary" value="<?php echo htmlspecialchars($employee['salary']); ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Start Date</label>
                    <input type="text" class="form-control" value="<?php echo date('M d, Y', strtotime($employee['start_date'])); ?>" readonly>
                </div>
                <button type="submit" class="btn btn-primary">Update Employee Details</button>
                <a href="employees.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
