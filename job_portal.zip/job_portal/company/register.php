<?php
session_start();
require_once '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = connectDB();

    // Sanitize inputs
    $companyName = sanitizeInput($_POST['company_name']);
    $email = sanitizeInput($_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];
    $description = sanitizeInput($_POST['description']);
    $location = sanitizeInput($_POST['location']);
    $website = sanitizeInput($_POST['website']);
    $phone = sanitizeInput($_POST['phone']);

    // Validate inputs
    $errors = [];

    if (empty($companyName)) {
        $errors[] = "Company name is required";
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email is required";
    }

    if (empty($phone) || !preg_match('/^\d{10}$/', $phone)) {
        $errors[] = "Phone number must be exactly 10 digits";
    }

    if (empty($password) || strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters long";
    }

    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match";
    }

    // Check if email already exists
    $stmt = $conn->prepare("SELECT email FROM companies WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errors[] = "Email already registered";
    }

    if (empty($errors)) {
        // Hash password
        $hashedPassword = hashPassword($password);

        // Insert new company
        $stmt = $conn->prepare("INSERT INTO companies (company_name, email, password, description, location, website, phone) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $companyName, $email, $hashedPassword, $description, $location, $website, $phone);

        if ($stmt->execute()) {
            redirectWithMessage('../index.php', 'Registration successful! Please login.', 'success');
        } else {
            $errors[] = "Registration failed. Please try again.";
        }
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Registration - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0?auto=format&fit=crop&w=1350&q=80') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
            color: #fff;
        }
        .registration-form {
            max-width: 800px;
            margin: 50px auto;
            padding: 30px;
            background-color: rgba(255, 255, 255, 0.95);
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
        }
        .registration-form h2 {
            color: black;
            font-weight: bold;
            text-align: center;
            margin-bottom: 25px;
        }
        label {
            color: black;
            font-weight: bold;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
            font-weight: bold;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-outline-secondary {
            font-weight: bold;
        }
        .alert {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="registration-form">
            <h2>Company Registration</h2>

            <?php
            if (!empty($errors)) {
                foreach ($errors as $error) {
                    echo "<div class='alert alert-danger'>$error</div>";
                }
            }
            ?>

            <form method="POST" action="">
                <div class="mb-3">
                    <label for="company_name" class="form-label">Company Name</label>
                    <input type="text" class="form-control" id="company_name" name="company_name" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Business Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Company Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3" placeholder="Tell us about your company"></textarea>
                </div>

                <div class="mb-3">
                    <label for="location" class="form-label">Location</label>
                    <input type="text" class="form-control" id="location" name="location" placeholder="City, Country">
                </div>

                <div class="mb-3">
                    <label for="website" class="form-label">Company Website</label>
                    <input type="url" class="form-control" id="website" name="website" placeholder="https://">
                </div>

                <div class="mb-3">
    <label for="phone" class="form-label">Business Phone</label>
    <input type="tel" class="form-control" id="phone" 
       name="phone" pattern="\d{10}" required inputmode="numeric" maxlength="10"
       oninput="this.value = this.value.replace(/\D/g, ''); if(this.value.length > 10) this.value = this.value.slice(0, 10);">

</div>


                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Register Company</button>
                    <a href="../index.php" class="btn btn-outline-secondary">Back to Home</a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
