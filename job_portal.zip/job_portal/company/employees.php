<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];

// Get all employees
$stmt = $conn->prepare("SELECT er.*, e.first_name, e.last_name, e.email, jp.title as job_title 
                       FROM employment_records er 
                       JOIN employees e ON er.employee_id = e.employee_id 
                       JOIN job_postings jp ON er.job_id = jp.job_id 
                       WHERE er.company_id = ? 
                       ORDER BY er.status ASC, er.start_date DESC");
$stmt->bind_param("i", $company_id);
$stmt->execute();
$employees = $stmt->get_result();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Employees - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Company Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="post-job.php">Post New Job</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage-jobs.php">Manage Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="applications.php">Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="employees.php">Employees</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <h2 class="mb-4">Manage Employees</h2>
        <?php echo displayMessage(); ?>

        <div class="card">
            <div class="card-body">
                <?php if ($employees->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Position</th>
                                    <th>Email</th>
                                    <th>Start Date</th>
                                    <th>Salary</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($employee = $employees->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></td>
                                        <td><?php echo htmlspecialchars($employee['job_title']); ?></td>
                                        <td><?php echo htmlspecialchars($employee['email']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($employee['start_date'])); ?></td>
                                        <td>$<?php echo number_format($employee['salary'], 2); ?></td>
                                        <td>
                                            <span class="badge bg-<?php echo $employee['status'] === 'Active' ? 'success' : 'secondary'; ?>">
                                                <?php echo $employee['status']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="edit-employee.php?id=<?php echo $employee['record_id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                                            <a href="salary-payment.php?id=<?php echo $employee['record_id']; ?>" class="btn btn-sm btn-success">Pay Salary</a>
                                            <?php if ($employee['status'] === 'Active'): ?>
                                               
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No employees found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
