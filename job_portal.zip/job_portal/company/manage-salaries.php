<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];

// Process salary payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process_payment'])) {
    $record_id = $_POST['record_id'];
    $amount = $_POST['amount'];
    $payment_date = $_POST['payment_date'];

    // Verify the employment record belongs to the company
    $stmt = $conn->prepare("SELECT * FROM employment_records WHERE record_id = ? AND company_id = ? AND status = 'Active'");
    $stmt->bind_param("ii", $record_id, $company_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $stmt = $conn->prepare("INSERT INTO salary_payments (record_id, amount, payment_date) VALUES (?, ?, ?)");
        $stmt->bind_param("ids", $record_id, $amount, $payment_date);
        
        if ($stmt->execute()) {
            redirectWithMessage('manage-salaries.php', 'Salary payment processed successfully', 'success');
        } else {
            redirectWithMessage('manage-salaries.php', 'Error processing payment', 'danger');
        }
    } else {
        redirectWithMessage('manage-salaries.php', 'Invalid employment record', 'danger');
    }
}

// Get all active employees and their salary information
$stmt = $conn->prepare("SELECT er.*, e.first_name, e.last_name, jp.title as job_title,
                              (SELECT COUNT(*) FROM salary_payments sp WHERE sp.record_id = er.record_id) as payments_count,
                              (SELECT payment_date FROM salary_payments sp WHERE sp.record_id = er.record_id ORDER BY payment_date DESC LIMIT 1) as last_payment_date
                       FROM employment_records er
                       JOIN employees e ON er.employee_id = e.employee_id
                       JOIN job_postings jp ON er.job_id = jp.job_id
                       WHERE er.company_id = ? AND er.status = 'Active'");
$stmt->bind_param("i", $company_id);
$stmt->execute();
$employees = $stmt->get_result();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Salaries - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Company Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="post-job.php">Post Job</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage-applications.php">Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="manage-salaries.php">Salaries</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <h2>Manage Employee Salaries</h2>
        <?php echo displayMessage(); ?>

        <div class="card">
            <div class="card-body">
                <?php if ($employees->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Employee</th>
                                    <th>Position</th>
                                    <th>Monthly Salary</th>
                                    <th>Start Date</th>
                                    <th>Last Payment</th>
                                    <th>Total Payments</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($employee = $employees->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></td>
                                        <td><?php echo htmlspecialchars($employee['job_title']); ?></td>
                                        <td>$<?php echo number_format($employee['salary'], 2); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($employee['start_date'])); ?></td>
                                        <td>
                                            <?php echo $employee['last_payment_date'] 
                                                ? date('M d, Y', strtotime($employee['last_payment_date']))
                                                : 'No payments yet'; ?>
                                        </td>
                                        <td><?php echo $employee['payments_count']; ?></td>
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#paymentModal<?php echo $employee['record_id']; ?>">
                                                Process Payment
                                            </button>
                                        </td>
                                    </tr>

                                    <!-- Payment Modal -->
                                    <div class="modal fade" id="paymentModal<?php echo $employee['record_id']; ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Process Salary Payment</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <form action="manage-salaries.php" method="post">
                                                    <div class="modal-body">
                                                        <input type="hidden" name="record_id" value="<?php echo $employee['record_id']; ?>">
                                                        <div class="mb-3">
                                                            <label class="form-label">Employee</label>
                                                            <input type="text" class="form-control" value="<?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>" readonly>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Amount</label>
                                                            <input type="number" class="form-control" name="amount" value="<?php echo $employee['salary']; ?>" step="0.01" required>
                                                        </div>
                                                        <div class="mb-3">
                                                            <label class="form-label">Payment Date</label>
                                                            <input type="date" class="form-control" name="payment_date" value="<?php echo date('Y-m-d'); ?>" required>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                        <button type="submit" name="process_payment" class="btn btn-primary">Process Payment</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No active employees found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>