<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];

// Process application status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $application_id = $_POST['application_id'];
    $new_status = $_POST['status'];
    $job_id = $_POST['job_id'];

    // Verify the job posting belongs to the company
    $stmt = $conn->prepare("SELECT * FROM job_postings WHERE job_id = ? AND company_id = ?");
    $stmt->bind_param("ii", $job_id, $company_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $stmt = $conn->prepare("UPDATE job_applications SET status = ? WHERE application_id = ?");
        $stmt->bind_param("si", $new_status, $application_id);
        
        if ($stmt->execute()) {
            // If hired, create employment record
            if ($new_status === 'Hired') {
                // Get job and employee details
                $stmt = $conn->prepare("SELECT ja.employee_id, jp.salary_range 
                                       FROM job_applications ja 
                                       JOIN job_postings jp ON ja.job_id = jp.job_id 
                                       WHERE ja.application_id = ?");
                $stmt->bind_param("i", $application_id);
                $stmt->execute();
                $hire_details = $stmt->get_result()->fetch_assoc();

                // Extract salary from salary range (assuming format like "$50000-$70000")
                $salary_parts = explode('-', str_replace('$', '', $hire_details['salary_range']));
                $salary = floatval($salary_parts[0]); // Use the lower bound of the range

                // Create employment record
                $stmt = $conn->prepare("INSERT INTO employment_records 
                                       (company_id, employee_id, job_id, start_date, salary) 
                                       VALUES (?, ?, ?, CURDATE(), ?)");
                $stmt->bind_param("iiid", $company_id, $hire_details['employee_id'], $job_id, $salary);
                $stmt->execute();

                // Close the job posting
                $stmt = $conn->prepare("UPDATE job_postings SET status = 'Closed' WHERE job_id = ?");
                $stmt->bind_param("i", $job_id);
                $stmt->execute();
            }
            redirectWithMessage('manage-applications.php', 'Application status updated successfully', 'success');
        } else {
            redirectWithMessage('manage-applications.php', 'Error updating application status', 'danger');
        }
    } else {
        redirectWithMessage('manage-applications.php', 'Invalid job posting', 'danger');
    }
}

// Get all applications for company's job postings
$stmt = $conn->prepare("SELECT ja.*, jp.title, e.first_name, e.last_name, e.email, e.resume_path,
                              e.skills, e.experience, e.education
                       FROM job_applications ja
                       JOIN job_postings jp ON ja.job_id = jp.job_id
                       JOIN employees e ON ja.employee_id = e.employee_id
                       WHERE jp.company_id = ?
                       ORDER BY ja.applied_at DESC");
$stmt->bind_param("i", $company_id);
$stmt->execute();
$applications = $stmt->get_result();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Applications - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Company Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="post-job.php">Post Job</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="manage-applications.php">Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage-salaries.php">Salaries</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <h2>Manage Job Applications</h2>
        <?php echo displayMessage(); ?>

        <div class="card">
            <div class="card-body">
                <?php if ($applications->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Job Title</th>
                                    <th>Applicant</th>
                                    <th>Applied Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($application = $applications->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($application['title']); ?></td>
                                        <td><?php echo htmlspecialchars($application['first_name'] . ' ' . $application['last_name']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($application['applied_at'])); ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo match($application['status']) {
                                                    'Pending' => 'warning',
                                                    'Reviewed' => 'info',
                                                    'Shortlisted' => 'primary',
                                                    'Rejected' => 'danger',
                                                    'Hired' => 'success',
                                                    default => 'secondary'
                                                }; 
                                            ?>">
                                                <?php echo $application['status']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#applicationModal<?php echo $application['application_id']; ?>">
                                                View Details
                                            </button>
                                        </td>
                                    </tr>

                                    <!-- Application Modal -->
                                    <div class="modal fade" id="applicationModal<?php echo $application['application_id']; ?>" tabindex="-1">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Application Details</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <h6>Applicant Information</h6>
                                                    <p><strong>Name:</strong> <?php echo htmlspecialchars($application['first_name'] . ' ' . $application['last_name']); ?></p>
                                                    <p><strong>Email:</strong> <?php echo htmlspecialchars($application['email']); ?></p>
                                                    
                                                    <h6 class="mt-4">Skills</h6>
                                                    <p><?php echo nl2br(htmlspecialchars($application['skills'])); ?></p>

                                                    <h6 class="mt-4">Experience</h6>
                                                    <p><?php echo nl2br(htmlspecialchars($application['experience'])); ?></p>

                                                    <h6 class="mt-4">Education</h6>
                                                    <p><?php echo nl2br(htmlspecialchars($application['education'])); ?></p>

                                                    <?php if ($application['resume_path']): ?>
                                                    <div class="mt-4">
                                                        <a href="<?php echo htmlspecialchars($application['resume_path']); ?>" 
                                                           class="btn btn-outline-primary" target="_blank">
                                                            <i class="fas fa-file-pdf me-2"></i>View Resume
                                                        </a>
                                                    </div>
                                                    <?php endif; ?>

                                                    <hr>

                                                    <form action="manage-applications.php" method="post">
                                                        <input type="hidden" name="application_id" value="<?php echo $application['application_id']; ?>">
                                                        <input type="hidden" name="job_id" value="<?php echo $application['job_id']; ?>">
                                                        <div class="mb-3">
                                                            <label class="form-label">Update Application Status</label>
                                                            <select class="form-select" name="status" required>
                                                                <option value="Pending" <?php echo $application['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                                                <option value="Reviewed" <?php echo $application['status'] === 'Reviewed' ? 'selected' : ''; ?>>Reviewed</option>
                                                                <option value="Shortlisted" <?php echo $application['status'] === 'Shortlisted' ? 'selected' : ''; ?>>Shortlisted</option>
                                                                <option value="Rejected" <?php echo $application['status'] === 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
                                                                <option value="Hired" <?php echo $application['status'] === 'Hired' ? 'selected' : ''; ?>>Hired</option>
                                                            </select>
                                                        </div>
                                                        <button type="submit" name="update_status" class="btn btn-primary">Update Status</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No applications received yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>