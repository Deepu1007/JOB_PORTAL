<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];

// Fetch unread notifications count
$notif_stmt = $conn->prepare("SELECT COUNT(*) as unread_count FROM notifications WHERE company_id = ? AND is_read = FALSE");
$notif_stmt->bind_param("i", $company_id);
$notif_stmt->execute();
$notif_result = $notif_stmt->get_result();
$notif_data = $notif_result->fetch_assoc();
$unread_notifications = $notif_data['unread_count'];
$notif_stmt->close();

// Get company information
$stmt = $conn->prepare("SELECT * FROM companies WHERE company_id = ?");
$stmt->bind_param("i", $company_id);
$stmt->execute();
$company = $stmt->get_result()->fetch_assoc();

// Get active job postings
$stmt = $conn->prepare("SELECT * FROM job_postings WHERE company_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $company_id);
$stmt->execute();
$job_postings = $stmt->get_result();

// Get recent applications
$stmt = $conn->prepare("SELECT ja.*, jp.title as job_title, e.first_name, e.last_name, e.email 
                       FROM job_applications ja 
                       JOIN job_postings jp ON ja.job_id = jp.job_id 
                       JOIN employees e ON ja.employee_id = e.employee_id 
                       WHERE jp.company_id = ? 
                       ORDER BY ja.applied_at DESC LIMIT 5");
$stmt->bind_param("i", $company_id);
$stmt->execute();
$recent_applications = $stmt->get_result();

// Get current employees
$stmt = $conn->prepare("SELECT er.*, e.first_name, e.last_name, e.email, jp.title as job_title 
                       FROM employment_records er 
                       JOIN employees e ON er.employee_id = e.employee_id 
                       JOIN job_postings jp ON er.job_id = jp.job_id 
                       WHERE er.company_id = ? AND er.status = 'Active'");
$stmt->bind_param("i", $company_id);
$stmt->execute();
$current_employees = $stmt->get_result();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Dashboard - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .dashboard-header {
            background-color: #f8f9fa;
            padding: 20px 0;
            margin-bottom: 30px;
        }
        .stat-card {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .stat-card i {
            font-size: 24px;
            margin-bottom: 10px;
            color: #0a66c2;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">Company Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="post-job.php">Post New Job</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage-jobs.php">Manage Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="applications.php">Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="employees.php">Employees</a>
                    </li>
                           
                    </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="dashboard-header">
        <div class="container">
            <h1>Welcome, <?php echo htmlspecialchars($company['company_name']); ?>!</h1>
        </div>
    </div>

    <div class="container mb-5">
        <?php echo displayMessage(); ?>
        <div class="mb-3">
            <a href="notifications.php" class="btn btn-info position-relative">
                View Notifications
                <?php if ($unread_notifications > 0): ?>
                    <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                        <?php echo $unread_notifications; ?>
                        <span class="visually-hidden">unread notifications</span>
                    </span>
                <?php endif; ?>
            </a>
        </div>
        <!-- Notifications Section Start -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Latest Notifications</h5>
                <a href="notifications.php" class="btn btn-primary btn-sm">View All</a>
            </div>
            <div class="card-body">
                <?php
                $conn = connectDB();
                $notif_stmt = $conn->prepare("SELECT n.message, n.created_at, e.first_name, e.last_name FROM notifications n LEFT JOIN employees e ON n.employee_id = e.employee_id WHERE n.company_id = ? ORDER BY n.created_at DESC LIMIT 5");
                $notif_stmt->bind_param("i", $company_id);
                $notif_stmt->execute();
                $notif_result = $notif_stmt->get_result();
                if ($notif_result->num_rows > 0):
                ?>
                    <ul class="list-group">
                        <?php while ($notif = $notif_result->fetch_assoc()): ?>
                            <li class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <?php if (!empty($notif['first_name'])): ?>
                                            <strong><?php echo htmlspecialchars($notif['first_name'] . ' ' . $notif['last_name']); ?>:</strong>
                                        <?php endif; ?>
                                        <?php echo htmlspecialchars($notif['message']); ?>
                                    </div>
                                    <small class="text-muted"><?php echo date('M d, Y H:i', strtotime($notif['created_at'])); ?></small>
                                </div>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                <?php else: ?>
                    <p class="text-muted mb-0">No notifications yet.</p>
                <?php endif; $notif_stmt->close(); $conn->close(); ?>
            </div>
        </div>
        <!-- Notifications Section End -->

        <div class="row">
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="fas fa-briefcase"></i>
                    <h3><?php echo $job_postings->num_rows; ?></h3>
                    <p class="text-muted">Active Job Postings</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="fas fa-users"></i>
                    <h3><?php echo $current_employees->num_rows; ?></h3>
                    <p class="text-muted">Current Employees</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="fas fa-file-alt"></i>
                    <h3><?php echo $recent_applications->num_rows; ?></h3>
                    <p class="text-muted">Recent Applications</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="fas fa-calendar-alt"></i>
                    <h3><?php echo date('M Y'); ?></h3>
                    <p class="text-muted">Current Period</p>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Recent Job Postings</h5>
                        <a href="post-job.php" class="btn btn-primary btn-sm">Post New Job</a>
                       
                    
                    </div>
                    <div class="card-body">
                        <?php if ($job_postings->num_rows > 0): ?>
                            <div class="list-group">
                                <?php while ($job = $job_postings->fetch_assoc()): ?>
                                    <a href="view-job.php?id=<?php echo $job['job_id']; ?>" class="list-group-item list-group-item-action">
                                        <div class="d-flex w-100 justify-content-between">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($job['title']); ?></h6>
                                            <small><?php echo $job['status']; ?></small>
                                        </div>
                                        <p class="mb-1"><?php echo htmlspecialchars(substr($job['description'], 0, 100)) . '...'; ?></p>
                                        <small>Posted: <?php echo date('M d, Y', strtotime($job['created_at'])); ?></small>
                                    </a>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No job postings yet.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Recent Applications</h5>
                        <a href="applications.php" class="btn btn-primary btn-sm">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if ($recent_applications->num_rows > 0): ?>
                            <div class="list-group">
                                <?php while ($application = $recent_applications->fetch_assoc()): ?>
                                    <a href="view-application.php?id=<?php echo $application['application_id']; ?>" class="list-group-item list-group-item-action">
                                        <div class="d-flex w-100 justify-content-between">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($application['first_name'] . ' ' . $application['last_name']); ?></h6>
                                            <small class="text-<?php echo $application['status'] === 'Pending' ? 'warning' : 'success'; ?>">
                                                <?php echo $application['status']; ?>
                                            </small>
                                        </div>
                                        <p class="mb-1">Applied for: <?php echo htmlspecialchars($application['job_title']); ?></p>
                                        <small>Applied: <?php echo date('M d, Y', strtotime($application['applied_at'])); ?></small>
                                    </a>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No recent applications.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Current Employees</h5>
                        <a href="employees.php" class="btn btn-primary btn-sm">Manage Employees</a>
                    </div>
                    <div class="card-body">
                        <?php if ($current_employees->num_rows > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Position</th>
                                            <th>Start Date</th>
                                            <th>Salary</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($employee = $current_employees->fetch_assoc()): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></td>
                                                <td><?php echo htmlspecialchars($employee['job_title']); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($employee['start_date'])); ?></td>
                                                <td>$<?php echo number_format($employee['salary'], 2); ?></td>
                                                <td><span class="badge bg-success">Active</span></td>
                                                <td>
                                                    <a href="edit-employee.php?id=<?php echo $employee['record_id']; ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                                    <a href="salary-payment.php?id=<?php echo $employee['record_id']; ?>" class="btn btn-sm btn-outline-success">Pay Salary</a>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">No current employees.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>