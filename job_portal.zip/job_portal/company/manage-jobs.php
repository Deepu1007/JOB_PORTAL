<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];

// Get all job postings
$stmt = $conn->prepare("SELECT jp.*, 
                        (SELECT COUNT(*) FROM job_applications ja WHERE ja.job_id = jp.job_id) as application_count 
                       FROM job_postings jp 
                       WHERE jp.company_id = ? 
                       ORDER BY jp.created_at DESC");
$stmt->bind_param("i", $company_id);
$stmt->execute();
$job_postings = $stmt->get_result();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Jobs - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Company Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="post-job.php">Post New Job</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="manage-jobs.php">Manage Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="applications.php">Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="employees.php">Employees</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Manage Job Postings</h2>
            <a href="post-job.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Post New Job
            </a>
        </div>
        <?php echo displayMessage(); ?>

        <div class="card">
            <div class="card-body">
                <?php if ($job_postings->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Location</th>
                                    <th>Salary Range</th>
                                    <th>Posted Date</th>
                                    <th>Applications</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($job = $job_postings->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($job['title']); ?></td>
                                        <td><?php echo htmlspecialchars($job['location']); ?></td>
                                        <td><?php echo htmlspecialchars($job['salary_range']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($job['created_at'])); ?></td>
                                        <td>
                                            <span class="badge bg-info">
                                                <?php echo $job['application_count']; ?> applications
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $job['status'] === 'Open' ? 'success' : 
                                                    ($job['status'] === 'Closed' ? 'danger' : 'secondary'); 
                                            ?>">
                                                <?php echo $job['status']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="edit-job.php?id=<?php echo $job['job_id']; ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                                <a href="view-job.php?id=<?php echo $job['job_id']; ?>" class="btn btn-sm btn-outline-info">View</a>
                                                <?php if ($job['status'] === 'Open'): ?>
                                                    <a href="update-job-status.php?id=<?php echo $job['job_id']; ?>&status=Closed" 
                                                       class="btn btn-sm btn-outline-danger"
                                                       onclick="return confirm('Are you sure you want to close this job posting?')">
                                                        Close
                                                    </a>
                                                <?php else: ?>
                                                    <a href="update-job-status.php?id=<?php echo $job['job_id']; ?>&status=Open" 
                                                       class="btn btn-sm btn-outline-success"
                                                       onclick="return confirm('Are you sure you want to reopen this job posting?')">
                                                        Reopen
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No job postings found. <a href="post-job.php">Create your first job posting</a></p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>