<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

if (!isset($_GET['id'])) {
    redirectWithMessage('employees.php', 'Invalid employee ID', 'danger');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];
$employment_id = $_GET['id'];

// Get employee details
$stmt = $conn->prepare("SELECT er.*, e.first_name, e.last_name, e.email 
                        FROM employment_records er 
                        JOIN employees e ON er.employee_id = e.employee_id 
                        WHERE er.record_id = ? AND er.company_id = ? AND er.status = 'Active'");
if (!$stmt) {
    die('Query preparation failed: ' . $conn->error);
}
$stmt->bind_param("ii", $employment_id, $company_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $conn->close();
    redirectWithMessage('employees.php', 'Employee not found or not active', 'danger');
}

$employee = $result->fetch_assoc();

// Handle salary payment
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = $_POST['amount'];
    $payment_date = date('Y-m-d');

    $stmt = $conn->prepare("INSERT INTO salary_payments (record_id, amount, payment_date) VALUES (?, ?, ?)");
    if (!$stmt) {
        die('Insert preparation failed: ' . $conn->error);
    }
    $stmt->bind_param("ids", $employment_id, $amount, $payment_date);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        redirectWithMessage('employees.php', 'Salary paid successfully', 'success');
    } else {
        redirectWithMessage('employees.php', 'Failed to pay salary', 'danger');
    }
}

// Display salary details
$stmt = $conn->prepare("SELECT amount, payment_date FROM salary_payments WHERE record_id = ? ORDER BY payment_date DESC LIMIT 1");
if (!$stmt) {
    die('Query preparation failed: ' . $conn->error);
}
$stmt->bind_param("i", $employment_id);
$stmt->execute();
$salary_result = $stmt->get_result();

if ($salary_result->num_rows > 0) {
    $salary = $salary_result->fetch_assoc();
    echo "<div class='alert alert-info'>Last Paid Salary: " . htmlspecialchars($salary['amount']) . " on " . date('M d, Y', strtotime($salary['payment_date'])) . "</div>";
} else {
    echo "<div class='alert alert-warning'>No salary payment records found.</div>";
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary Payment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Salary Payment for <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></h2>
        <div class="card mb-4">
            <div class="card-header">Employee Details</div>
            <div class="card-body">
                <p><strong>Position:</strong> <?php echo htmlspecialchars($employee['position']); ?></p>
                <p><strong>Base Salary:</strong> <?php echo htmlspecialchars($employee['salary']); ?></p>
                <p><strong>Start Date:</strong> <?php echo date('M d, Y', strtotime($employee['start_date'])); ?></p>
            </div>
        </div>
        
        <form method="post">
            <div class="mb-3">
                <label for="amount" class="form-label">Payment Amount</label>
                <input type="number" class="form-control" id="amount" name="amount" value="<?php echo htmlspecialchars($employee['salary']); ?>" required>
                <div class="form-text">The amount is automatically set to the employee's current base salary.</div>
            </div>
            <button type="submit" class="btn btn-primary">Pay Salary</button>
            <a href="employees.php" class="btn btn-secondary">Back to Employees</a>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>