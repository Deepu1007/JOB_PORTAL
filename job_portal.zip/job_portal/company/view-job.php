<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

if (!isset($_GET['id'])) {
    redirectWithMessage('manage-jobs.php', 'Invalid job ID', 'danger');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];
$job_id = $_GET['id'];

// Get job details
$stmt = $conn->prepare("SELECT * FROM job_postings WHERE job_id = ? AND company_id = ?");
$stmt->bind_param("ii", $job_id, $company_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $conn->close();
    redirectWithMessage('manage-jobs.php', 'Job not found', 'danger');
}

$job = $result->fetch_assoc();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Job - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container my-4">
        <h2>View Job Details</h2>
        <div class="card">
            <div class="card-body">
                <h3><?php echo htmlspecialchars($job['title']); ?></h3>
                <p><strong>Location:</strong> <?php echo htmlspecialchars($job['location']); ?></p>
                <p><strong>Salary Range:</strong> <?php echo htmlspecialchars($job['salary_range']); ?></p>
                <p><strong>Description:</strong> <?php echo htmlspecialchars($job['description']); ?></p>
                <p><strong>Requirements:</strong> <?php echo htmlspecialchars($job['requirements']); ?></p>
                <p><strong>Status:</strong> <?php echo htmlspecialchars($job['status']); ?></p>
            </div>
        </div>
        <a href="manage-jobs.php" class="btn btn-secondary mt-3">Back to Manage Jobs</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>