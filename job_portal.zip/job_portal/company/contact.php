<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Us - Job Portal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .hero {
      background-color: #003366; /* Company dark blue */
      color: white;
      padding: 70px 0;
      text-align: center;
    }
    .info-card {
      background-color: #ffffff;
      border-radius: 10px;
      border: 1px solid #dee2e6;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
      padding: 30px;
    }
    .info-card h4 {
      color: #003366;
      font-weight: 600;
      margin-bottom: 20px;
    }
    .info-item {
      display: flex;
      align-items: center;
      margin-bottom: 15px;
    }
    .info-item i {
      font-size: 20px;
      color: #003366;
      margin-right: 10px;
    }
    a {
      color: #003366;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
    footer {
      background-color: #1c1c1c;
      color: #aaa;
      padding: 20px 0;
      font-size: 14px;
    }
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand fw-bold" href="../index.php">JobPortal Inc.</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
        <li class="nav-item"><a class="nav-link active" href="contact.php">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero">
  <div class="container">
    <h1 class="display-5 fw-semibold">Contact Us</h1>
    <p class="lead">We're here to support your career journey. Get in touch with us.</p>
  </div>
</section>

<!-- Contact Info -->
<section class="py-5">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-8">
        <div class="info-card">
          <h4>Reach Our Team</h4>
          <div class="info-item"><i class="fas fa-envelope"></i> <strong>Email:</strong>&nbsp; deepak@gmail.com</div>
          <div class="info-item"><i class="fas fa-phone"></i> <strong>Phone:</strong>&nbsp; +91 96634 60852</div>
          <div class="info-item"><i class="fas fa-map-marker-alt"></i> <strong>Address:</strong>&nbsp; Opp. RV College, Mysore Road, Bengaluru 560059</div>
          <div class="info-item"><i class="fas fa-clock"></i> <strong>Working Hours:</strong>&nbsp; Mon - Fri: 9:00 AM - 6:00 PM</div>
          <div class="info-item"><i class="fas fa-globe"></i> <strong>Website:</strong>&nbsp; <a href="https://www.jobportal.com" target="_blank">www.jobportal.com</a></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Footer -->
<footer class="text-center">
  <div class="container">
    <p class="mb-0">© <?php echo date("Y"); ?> JobPortal Inc. All rights reserved.</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
