<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

if (!isset($_GET['id'])) {
    redirectWithMessage('applications.php', 'Invalid application ID', 'danger');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];
$application_id = $_GET['id'];

// Get application details with job and employee information
$stmt = $conn->prepare("SELECT ja.*, jp.title as job_title, jp.description as job_description, 
                        jp.requirements, jp.salary_range, jp.location,
                        e.first_name, e.last_name, e.email, e.skills, e.experience, e.education, e.phone, e.address
                        FROM job_applications ja 
                        JOIN job_postings jp ON ja.job_id = jp.job_id 
                        JOIN employees e ON ja.employee_id = e.employee_id 
                        WHERE ja.application_id = ? AND jp.company_id = ?");
if (!$stmt) {
    die('SQL Error: ' . $conn->error);
}
$stmt->bind_param("ii", $application_id, $company_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $conn->close();
    redirectWithMessage('applications.php', 'Application not found', 'danger');
}

$application = $result->fetch_assoc();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Application - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Company Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="post-job.php">Post New Job</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage-jobs.php">Manage Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="applications.php">Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="employees.php">Employees</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <div class="row mb-3">
            <div class="col">
                <h2>Application Details</h2>
            </div>
            <div class="col text-end">
                <a href="applications.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Applications
                </a>
            </div>
        </div>

        <?php echo displayMessage(); ?>

        <div class="row">
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Job Information</h5>
                    </div>
                    <div class="card-body">
                        <h4><?php echo htmlspecialchars($application['job_title']); ?></h4>
                        <p><strong>Salary Range:</strong> <?php echo htmlspecialchars($application['salary_range']); ?></p>
                        <p><strong>Location:</strong> <?php echo htmlspecialchars($application['location']); ?></p>
                        <p><strong>Description:</strong></p>
                        <p><?php echo nl2br(htmlspecialchars($application['job_description'])); ?></p>
                        <p><strong>Requirements:</strong></p>
                        <p><?php echo nl2br(htmlspecialchars($application['requirements'])); ?></p>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Applicant Information</h5>
                    </div>
                    <div class="card-body">
                        <h4><?php echo htmlspecialchars($application['first_name'] . ' ' . $application['last_name']); ?></h4>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($application['email']); ?></p>
                        <p><strong>Phone:</strong> <?php echo htmlspecialchars($application['phone']); ?></p>
                        <p><strong>Address:</strong> <?php echo htmlspecialchars($application['address']); ?></p>
                        
                        <h5 class="mt-4">Skills</h5>
                        <p><?php echo nl2br(htmlspecialchars($application['skills'])); ?></p>
                        
                        <h5 class="mt-4">Experience</h5>
                        <p><?php echo nl2br(htmlspecialchars($application['experience'])); ?></p>
                        
                        <h5 class="mt-4">Education</h5>
                        <p><?php echo nl2br(htmlspecialchars($application['education'])); ?></p>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Application Status</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Status:</strong> 
                            <span class="badge bg-<?php 
                                echo $application['status'] === 'Pending' ? 'warning' : 
                                    ($application['status'] === 'Approved' ? 'success' : 'danger'); 
                            ?>">
                                <?php echo $application['status']; ?>
                            </span>
                        </p>
                        <p><strong>Applied Date:</strong> <?php echo date('M d, Y', strtotime($application['applied_at'])); ?></p>
                        
                        <?php if ($application['status'] === 'Pending'): ?>
                            <div class="d-grid gap-2">
                                <a href="process-application.php?id=<?php echo $application_id; ?>&action=approve" 
                                   class="btn btn-success"
                                   onclick="return confirm('Are you sure you want to approve this application?')">
                                    <i class="fas fa-check"></i> Approve Application
                                </a>
                                <a href="process-application.php?id=<?php echo $application_id; ?>&action=reject" 
                                   class="btn btn-danger"
                                   onclick="return confirm('Are you sure you want to reject this application?')">
                                    <i class="fas fa-times"></i> Reject Application
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>