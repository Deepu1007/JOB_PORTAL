<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

if (!isset($_GET['id']) || !isset($_GET['action']) || !in_array($_GET['action'], ['approve', 'reject'])) {
    redirectWithMessage('applications.php', 'Invalid request', 'danger');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];
$application_id = $_GET['id'];
$action = $_GET['action'];

// Verify the application belongs to this company
$stmt = $conn->prepare("SELECT ja.*, jp.company_id, e.email, e.first_name, e.last_name, jp.title 
                       FROM job_applications ja 
                       JOIN job_postings jp ON ja.job_id = jp.job_id 
                       JOIN employees e ON ja.employee_id = e.employee_id 
                       WHERE ja.application_id = ? AND jp.company_id = ? AND ja.status = 'Pending'");
$stmt->bind_param("ii", $application_id, $company_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $conn->close();
    redirectWithMessage('applications.php', 'Application not found or already processed', 'danger');
}

$application = $result->fetch_assoc();
$new_status = $action === 'approve' ? 'Approved' : 'Rejected';

// Check if the employee is already employed
$stmt = $conn->prepare("SELECT * FROM employment_records WHERE employee_id = ? AND status = 'Active'");
$stmt->bind_param("i", $application['employee_id']);
$stmt->execute();
$employment_check = $stmt->get_result();

if ($employment_check->num_rows > 0 && $action === 'approve') {
    $conn->close();
    redirectWithMessage('applications.php', 'Employee is already employed and cannot be approved for another job', 'danger');
}

// Update application status
$stmt = $conn->prepare("UPDATE job_applications SET status = ? WHERE application_id = ?");
$stmt->bind_param("si", $new_status, $application_id);

if ($stmt->execute()) {
    // If approved, create employment record and update job posting
    if ($action === 'approve') {
        $stmt = $conn->prepare("INSERT INTO employment_records (employee_id, company_id, job_id, start_date, status) 
                                VALUES (?, ?, ?, CURRENT_DATE, 'Active')");
        $stmt->bind_param("iii", $application['employee_id'], $company_id, $application['job_id']);
        $stmt->execute();

        // Update job posting status
        $stmt = $conn->prepare("UPDATE job_postings SET status = 'Filled' WHERE job_id = ?");
        $stmt->bind_param("i", $application['job_id']);
        $stmt->execute();

        // Reject other pending applications
        $stmt = $conn->prepare("UPDATE job_applications 
                                SET status = 'Rejected' 
                                WHERE job_id = ? AND application_id != ? AND status = 'Pending'");
        $stmt->bind_param("ii", $application['job_id'], $application_id);
        $stmt->execute();
    }

    $message = "Application has been " . strtolower($new_status);
    $message_type = $action === 'approve' ? 'success' : 'info';

    $conn->close();
    redirectWithMessage('applications.php', $message, $message_type);
} else {
    $conn->close();
    redirectWithMessage('applications.php', 'Failed to update application status', 'danger');
}
