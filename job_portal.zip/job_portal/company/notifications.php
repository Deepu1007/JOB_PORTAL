<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];

// Fetch notifications
$stmt = $conn->prepare("SELECT n.notification_id, n.message, n.created_at, n.is_read, e.first_name, e.last_name 
                        FROM notifications n 
                        LEFT JOIN employees e ON n.employee_id = e.employee_id 
                        WHERE n.company_id = ? 
                        ORDER BY n.created_at DESC");
if (!$stmt) {
    die('Query preparation failed: ' . $conn->error);
}
$stmt->bind_param("i", $company_id);
$stmt->execute();
$result = $stmt->get_result();

// Mark notifications as read
if ($result->num_rows > 0) {
    $update_stmt = $conn->prepare("UPDATE notifications SET is_read = TRUE WHERE company_id = ? AND is_read = FALSE");
    if ($update_stmt) {
        $update_stmt->bind_param("i", $company_id);
        $update_stmt->execute();
        $update_stmt->close();
    }
}

$conn->close();

?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Company Notifications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h2>Notifications</h2>
        <?php if ($result->num_rows > 0): ?>
            <div class="list-group" id="notifications-list">
                <?php while ($notification = $result->fetch_assoc()): ?>
                    <button type="button" class="list-group-item list-group-item-action <?php echo $notification['is_read'] ? '' : 'list-group-item-primary'; ?>" data-bs-toggle="modal" data-bs-target="#notificationModal" data-message="<?php echo htmlspecialchars($notification['message'], ENT_QUOTES); ?>" data-date="<?php echo date('M d, Y H:i', strtotime($notification['created_at'])); ?>">
                        <div class="d-flex w-100 justify-content-between">
                            <h5 class="mb-1"><?php echo htmlspecialchars($notification['message']); ?></h5>
                            <small><?php echo date('M d, Y H:i', strtotime($notification['created_at'])); ?></small>
                        </div>
                    </button>
                <?php endwhile; ?>
            </div>
            <!-- Modal -->
            <div class="modal fade" id="notificationModal" tabindex="-1" aria-labelledby="notificationModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="notificationModalLabel">Notification Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                    <p id="modal-message"></p>
                    <small id="modal-date" class="text-muted"></small>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  </div>
                </div>
              </div>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">No notifications found.</div>
        <?php endif; ?>
        <div class="mt-3">
            <a href="dashboard.php" class="btn btn-primary">Back to Dashboard</a>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    var notificationModal = document.getElementById('notificationModal');
    notificationModal.addEventListener('show.bs.modal', function (event) {
      var button = event.relatedTarget;
      var message = button.getAttribute('data-message');
      var date = button.getAttribute('data-date');
      var modalMessage = notificationModal.querySelector('#modal-message');
      var modalDate = notificationModal.querySelector('#modal-date');
      modalMessage.textContent = message;
      modalDate.textContent = date;
    });
    </script>
</body>
</html>