<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>About Us - Job Portal</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .hero {
      background-color: #003366;
      color: white;
      padding: 70px 0;
      text-align: center;
    }
    .section {
      padding: 60px 0;
    }
    .team-card {
      border: 1px solid #dee2e6;
      border-radius: 15px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
      padding: 30px;
    }
    footer {
      background-color: #1c1c1c;
      color: #aaa;
      padding: 20px 0;
      font-size: 14px;
    }
    .navbar-brand {
      font-weight: bold;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="dashboard.php">Job Portal</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li><a class="nav-link active" href="../index.php">Home</a></li>
        <li><a class="nav-link active" href="about.php">About</a></li>
        <li><a class="nav-link" href="contact.php">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero">
  <div class="container">
    <h1 class="display-4">About Job Portal</h1>
    <p class="lead">Connecting talented people with great opportunities</p>
  </div>
</section>

<!-- Mission Section -->
<section class="section text-center">
  <div class="container">
    <h2 class="mb-4">Our Mission</h2>
    <p class="lead">We aim to simplify and streamline the recruitment process for companies and job seekers. Our platform is designed to help organizations find the right talent and assist candidates in landing their dream jobs.</p>
  </div>
</section>

<!-- Team Section -->
<section class="section bg-white">
  <div class="container">
    <h2 class="text-center mb-5">Meet Our Team</h2>
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card team-card text-center">
          <img src="https://via.placeholder.com/150" class="rounded-circle mx-auto mb-3" alt="Founder">
          <h5 class="card-title">Jane Doe</h5>
          <p class="card-text">Founder & CEO</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card team-card text-center">
          <img src="https://via.placeholder.com/150" class="rounded-circle mx-auto mb-3" alt="Developer">
          <h5 class="card-title">John Smith</h5>
          <p class="card-text">Lead Developer</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card team-card text-center">
          <img src="https://via.placeholder.com/150" class="rounded-circle mx-auto mb-3" alt="Designer">
          <h5 class="card-title">Emily Johnson</h5>
          <p class="card-text">UI/UX Designer</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Footer -->
<footer class="text-center">
  <div class="container">
    <p class="mb-0">© <?php echo date("Y"); ?> Job Portal. All rights reserved.</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
