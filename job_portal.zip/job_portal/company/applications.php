<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];

// Get all job applications
$stmt = $conn->prepare("SELECT ja.*, jp.title as job_title, e.first_name, e.last_name, e.email 
                       FROM job_applications ja 
                       JOIN job_postings jp ON ja.job_id = jp.job_id 
                       JOIN employees e ON ja.employee_id = e.employee_id 
                       WHERE jp.company_id = ? 
                       ORDER BY ja.applied_at DESC");
$stmt->bind_param("i", $company_id);
$stmt->execute();
$applications = $stmt->get_result();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Applications - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Company Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="post-job.php">Post New Job</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="manage-jobs.php">Manage Jobs</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="applications.php">Applications</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="employees.php">Employees</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="profile.php">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <h2 class="mb-4">Job Applications</h2>
        <?php echo displayMessage(); ?>

        <div class="card">
            <div class="card-body">
                <?php if ($applications->num_rows > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Applicant Name</th>
                                    <th>Email</th>
                                    <th>Job Position</th>
                                    <th>Applied Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($application = $applications->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($application['first_name'] . ' ' . $application['last_name']); ?></td>
                                        <td><?php echo htmlspecialchars($application['email']); ?></td>
                                        <td><?php echo htmlspecialchars($application['job_title']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($application['applied_at'])); ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $application['status'] === 'Pending' ? 'warning' : 
                                                    ($application['status'] === 'Approved' ? 'success' : 'danger'); 
                                            ?>">
                                                <?php echo $application['status']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="view-application.php?id=<?php echo $application['application_id']; ?>" 
                                                   class="btn btn-sm btn-outline-primary">
                                                   View
                                                </a>
                                                <?php if ($application['status'] === 'Pending'): ?>
                                                    <a href="process-application.php?id=<?php echo $application['application_id']; ?>&action=approve" 
                                                       class="btn btn-sm btn-outline-success"
                                                       onclick="return confirm('Are you sure you want to approve this application?')">
                                                        Approve
                                                    </a>
                                                    <a href="process-application.php?id=<?php echo $application['application_id']; ?>&action=reject" 
                                                       class="btn btn-sm btn-outline-danger"
                                                       onclick="return confirm('Are you sure you want to reject this application?')">
                                                        Reject
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted">No applications found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>