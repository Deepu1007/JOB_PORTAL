<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

if (!isset($_GET['id']) || !isset($_GET['status'])) {
    redirectWithMessage('manage-jobs.php', 'Invalid request', 'danger');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];
$job_id = $_GET['id'];
$new_status = $_GET['status'];

// Validate status
if (!in_array($new_status, ['Open', 'Closed'])) {
    redirectWithMessage('manage-jobs.php', 'Invalid status', 'danger');
}

// Verify job belongs to company
$stmt = $conn->prepare("SELECT job_id FROM job_postings WHERE job_id = ? AND company_id = ?");
$stmt->bind_param("ii", $job_id, $company_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $conn->close();
    redirectWithMessage('manage-jobs.php', 'Job not found', 'danger');
}

// Update job status
$stmt = $conn->prepare("UPDATE job_postings SET status = ? WHERE job_id = ? AND company_id = ?");
$stmt->bind_param("sii", $new_status, $job_id, $company_id);

if ($stmt->execute()) {
    $message = $new_status === 'Open' ? 'Job reopened successfully' : 'Job closed successfully';
    $conn->close();
    redirectWithMessage('manage-jobs.php', $message, 'success');
} else {
    $conn->close();
    redirectWithMessage('manage-jobs.php', 'Failed to update job status', 'danger');
}