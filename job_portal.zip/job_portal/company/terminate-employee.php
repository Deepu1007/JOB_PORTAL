<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

if (!isset($_GET['id'])) {
    redirectWithMessage('employees.php', 'Invalid employee ID', 'danger');
}

$conn = connectDB();
$company_id = $_SESSION['user_id'];
$employment_id = $_GET['id'];

// Get employee details
$stmt = $conn->prepare("SELECT er.*, e.first_name, e.last_name, e.email 
                        FROM employment_records er 
                        JOIN employees e ON er.employee_id = e.employee_id 
                        WHERE er.record_id = ? AND er.company_id = ? AND er.status = 'Active'");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("ii", $employment_id, $company_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $conn->close();
    redirectWithMessage('employees.php', 'Employee not found or already terminated', 'danger');
}

$employee = $result->fetch_assoc();

// Handle termination
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $termination_date = $_POST['termination_date'];
    $reason = $_POST['reason'];

    $stmt = $conn->prepare("UPDATE employment_records \n SET status = 'Terminated', \n end_date = ?, \n termination_reason = ? \n WHERE record_id = ? AND company_id = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("ssii", $termination_date, $reason, $employment_id, $company_id);

    if ($stmt->execute()) {
        redirectWithMessage('employees.php', 'Employee terminated successfully', 'success');
    } else {
        $error = 'Failed to terminate employee';
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terminate Employee - Job Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Company Dashboard</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="employees.php">Employees</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container my-4">
        <h2>Terminate Employee</h2>
        <?php echo displayMessage(); ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <div class="alert alert-warning">
                    <h5>Warning!</h5>
                    <p>You are about to terminate the employment of:</p>
                    <p><strong><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></strong></p>
                    <p>This action cannot be undone. Please make sure you want to proceed.</p>
                </div>

                <form method="POST" action="" onsubmit="return confirm('Are you sure you want to terminate this employee?');">
                    <div class="mb-3">
                        <label class="form-label">Termination Date</label>
                        <input type="date" class="form-control" name="termination_date" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Reason for Termination</label>
                        <textarea class="form-control" name="reason" rows="3" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-danger">Confirm Termination</button>
                    <a href="employees.php" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

