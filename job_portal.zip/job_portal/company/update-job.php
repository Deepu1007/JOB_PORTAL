<?php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'company') {
    redirectWithMessage('login.php', 'Please login first', 'warning');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = connectDB();
    $company_id = $_SESSION['user_id'];
    $job_id = $_POST['job_id'];
    $title = $_POST['title'];
    $location = $_POST['location'];
    $salary_range = $_POST['salary_range'];
    $description = $_POST['description'];
    $requirements = $_POST['requirements'];

    $stmt = $conn->prepare("UPDATE job_postings SET title = ?, location = ?, salary_range = ?, description = ?, requirements = ? WHERE job_id = ? AND company_id = ?");
    $stmt->bind_param("ssssiii", $title, $location, $salary_range, $description, $requirements, $job_id, $company_id);

    if ($stmt->execute()) {
        redirectWithMessage('manage-jobs.php', 'Job updated successfully', 'success');
    } else {
        redirectWithMessage('edit-job.php?id=' . $job_id, 'Failed to update job', 'danger');
    }

    $stmt->close();
    $conn->close();
} else {
    redirectWithMessage('manage-jobs.php', 'Invalid request method', 'danger');
}
?>